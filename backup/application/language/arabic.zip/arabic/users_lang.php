<?php

$lang['block_success'] = 'User has been blocked successfully!';
$lang['unblock_success'] = 'User has been unblocked successfully!';

$lang['block_error'] = 'User has been failed to block.';
$lang['unblock_error'] = 'User has been failed to unblock.';


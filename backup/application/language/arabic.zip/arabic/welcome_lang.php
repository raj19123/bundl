<?php

$lang['login_page'] = 'SIGN-IN USING';
$lang['login_error'] = 'Error!';
$lang['login_signin_btn'] = 'SIGN - I N';
$lang['login_register_link'] = 'register';
$lang['register_btn'] = 'register';
$lang['back_to_login_link'] = '< Back to Login >';

$lang['result_text'] = 'RESULTS';
$lang['result_info'] = 'Info!';

$lang['result_noresult_found'] = 'No results found!';

$lang['login_success_message'] = 'You Have Successfully Logged Out Of Your Account.';
$lang['login_error'] = 'Incorrect user name/password combination being used.';
$lang['email_error'] = 'Email is not found. Please try again.';

$lang['placeholder_pro'] = 'name of project';
$lang['bundle_detail'] = 'BUNDL DETAILS';

$lang['work_days'] = 'working days';
$lang['logo_design'] = 'Logo Design';
$lang['arbi'] = 'Arabic';
$lang['engl'] = 'English';
$lang['both'] = 'Both';

$lang['addto_cart'] = 'ADD TO CART';

$lang['select_btn'] = 'SELECT';
$lang['webster'] = 'THE WEBSTER';
$lang['webster_cutomize'] = '< customise your website >';
$lang['webstar_description'] = 'Lorem ipsum dorem ipset<br> peret delet Lorem ipsum<br> dorem ipset peret delet Lorem ipsum dorem ipset peret delet Lorem ipsum dorem ipset peret delet Lorem ipsum dorem ipset peret delet Lore';
$lang['customize_bun'] = 'CUSTOMISE BUNDL';
$lang['customize_bun_mix'] = '< mix + match >';
$lang['recent_work'] = 'RECENT WORK';
$lang['viewwork_btn'] = 'View work';
$lang['testimonials'] = 'TESTIMONIALS';
$lang['testimonials_descrition'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incre magna';

$lang['customize_bunndle'] = 'CUSTOMISE<br> BUNDL';
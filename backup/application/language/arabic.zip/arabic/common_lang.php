<?php
//common lines for all lang files [start]
$lang['welcome_message'] = 'Welcome to Bundl';
$lang['promotion_message'] = 'NEW YEAR PROMOTION PROMO CODE: NY2018 GET 20% OFF';

$lang['sidebar'] = 'ITEMS IN YOUR CART:';
$lang['sidebar_adjustment'] = 'Adjustments:';
$lang['cart_qty'] = 'QTY:';
$lang['sidebar_addone'] = 'Add-ons to BUNDL:';
$lang['sidebar_none_text'] = 'None';
$lang['sidebar_total_text'] = 'total :';
$lang['sidebar_duration'] = 'DURATION:';
$lang['sidebar_success_msg'] = 'ADDED TO CART SUCCESFULLY!';
$lang['sidebar_btn'] = 'go to cart';

$lang['addon_addquantity'] = '(add quantity for multiple content/ language/ or measurements) ';

$lang['addon_side'] = 'side:';
$lang['oneside'] = 'One-side';
$lang['twoside'] = 'Two-side';
$lang['threeside'] = 'Three-side';
$lang['addon_fold'] = 'fold:';
$lang['monofold'] = 'Mono-fold';
$lang['bifold'] = 'Bi-fold';
$lang['trifold'] = 'Tri-fold';
$lang['addon_pages'] = 'pages:';

$lang['header_myfiles_li'] = 'my files';
$lang['header_prifile_li'] = 'profile';
$lang['header_orderhistory_li'] = 'order history';
$lang['header_logout_li'] = 'logout';

$lang['header_bundl_li'] = 'Bundls';
$lang['header_ourwork_li'] = 'Our Work';
$lang['header_contectus_lii'] = 'Contact Us';

$lang['aboutus_buy'] = 'Buy Bundl';
$lang['aboutus_branding_description'] = 'Choose the design package that is right for you. Amend and Add 								to your package by upgrading your bundl';
$lang['fill_question'] = 'Fill Questionnaire';
$lang['aboutus_graphic_description'] = 'Tell us about your business and what you need designed. Take 									your time. The more details, the better your designs.';
$lang['get_design'] = 'Get Designs';
$lang['web_design_description'] = 'Get your designs online by logging into your account. Add, amend or 							upgrade you design.';

$lang['day'] = 'days';
$lang['sar'] = 'SAR';
$lang['add_ons'] = 'ADD-ONS TO BUNDL';
$lang['name_bundle'] = 'NAME YOUR BUNDL:';

$lang['footer_stay_connected'] = 'stay connected';
$lang['footer_signup'] = 'SIGN UP FOR OUR NEWLETTER';
$lang['footer_placeholder_email'] = 'example@mail.com';
$lang['newsletter'] = 'YOU ARE SUCCESSFULLY SIGNED-UP FOR NEWSLETTER';
$lang['footer_customer_care'] = 'CUSTOMER CARE';
$lang['footer_contectus_li'] = 'contact us';
$lang['footer_faq_li'] = 'FAQs';
$lang['footer_careers_li'] = 'careers';
$lang['footer_dashbord'] = 'MY DASHBOARD';
$lang['footer_profile_li'] = 'my profile';
$lang['footer_feedback_li'] = 'feedback';
$lang['footer_recomend_li'] = 'recomend us';
$lang['footer_information'] = 'INFORMATION';
$lang['footer_aboutus_li'] = 'about us';
$lang['footer_terms_condition'] = 'terms & conditions';
$lang['footer_legal'] = 'Legal';
$lang['contactus_name'] = 'name';
$lang['contactus_received_alert'] = 'MESSAGE RECIEVED, WE WILL GET BACK TO YOU SHORTLY';
$lang['placeholder_password'] = 'password';
$lang['login_fordot_pass_link'] = 'FORGOT PASSWORD';
$lang['send_btn'] = 'SEND';
$lang['footer_signup_btn'] = 'sign up';

$lang['reset_password'] = 'Reset password email has been successfully sent.';

$lang['bundl_detail'] = 'Lorem Ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.';

$lang['contactus_message'] = 'message';
$lang['contactus_sending'] = 'SENDING...';

$lang['header_my_files'] = 'my files';
$lang['header_login'] = 'login';

//common lines [end]
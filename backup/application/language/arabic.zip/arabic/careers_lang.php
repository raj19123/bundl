<?php 

$lang['update_success'] = 'Edited vacancy has been successfully updated.';
$lang['update_error'] = 'Edited vacancy has been failed to update.';

$lang['add_success'] = 'A new vacancy has been successfully added.';
$lang['add_error'] = 'A new vacancy has been failed to add.';

$lang['delete_success'] = 'Vacancy has been successfully deleted.';
$lang['delete_error'] = 'Vacancy has been failed to delete.';

$lang['delete_applicant_success'] = 'Application has been successfully deleted.';
$lang['delete_applicant_error'] = 'Application has been failed to delete.';
$lang['contact_us'] = 'CONTACT US';
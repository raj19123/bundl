<?php 

$lang['update_success'] = 'Edited project has been successfully updated.';
$lang['update_error'] = 'Edited project has been failed to update.';

$lang['add_success'] = 'A new project has been successfully added.';
$lang['add_error'] = 'A new project has been failed to add.';

$lang['delete_success'] = 'Project has been successfully deleted.';
$lang['delete_error'] = 'Project has been failed to delete.';


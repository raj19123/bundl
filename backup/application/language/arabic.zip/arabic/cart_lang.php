<?php

$lang['success_cart'] = 'Item has been removed successfully from the cart.';
$lang['empty_cart'] = 'there are no items in your cart.';



$lang['cart_buybundle'] = 'Buy Bundl';
$lang['cart_fillquestion'] = 'Fill Questionnaire';
$lang['cart_getdesign'] = 'Get Designs';
$lang['cart_mycart'] = 'MY CART';
$lang['cart_bundlename_li'] = 'BUNDL NAME';
$lang['cart_items_li'] = 'ITEMS';
$lang['cart_description_li'] = 'DESCREPTION';
$lang['cart_adjustment_li'] = 'ADJUSMENTS';
$lang['cart_discard'] = 'discard';
$lang['cart_logo_identity'] = '- Logo & Identity';
$lang['cart_sar'] = 'SAR';
$lang['cart_days'] = 'days';
$lang['cart_qty'] = 'QTY:';
$lang['cart_update'] = 'update';
$lang['cart_adjustment'] = 'ADJUSTMENTS';
$lang['cart_delete'] = 'delete';
$lang['cart_addone'] = 'ADD-ONS';
$lang['cart_alert'] = 'Alert!';
$lang['cart_duration'] = 'DURATION:';
$lang['cart_working_days'] = 'WORKING DAYS';


$lang['billing_adress'] = 'BILLING ADDRESS';
$lang['cart_checkout_text'] = 'CHECKOUT';
$lang['aboutus_craditcard'] = 'CREDIT CARD';
$lang['mada_payment'] = 'Mada Payment';
$lang['promo_code'] = 'PROMO CODE';
$lang['applay_code'] = '< APPLY CODE >';
$lang['i_agree'] = 'I agree to the cancellation policy and';
$lang['place_order_btn'] = 'PLACE  ORDER';
$lang['placeholder_firstname'] = 'first name on credit card';
$lang['placeholder_lastname'] = 'last name on credit card';
$lang['email_text'] = 'email';
$lang['city_text'] = 'city';
$lang['state_text'] = 'state';
$lang['postal_code_text'] = 'postal code';
$lang['code_number_text'] = 'code number';
$lang['contactus_name'] = 'name';













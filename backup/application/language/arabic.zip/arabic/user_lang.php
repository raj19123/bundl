<?php

$lang['login_success_message'] = 'You Have Successfully Logged Out Of Your Account.';
$lang['login_error'] = 'Incorrect user name/password combination being used.';
$lang['email_error'] = 'Email is not found. Please try again.';

$lang['update_success_password'] = 'Password has been changed successfully!';
$lang['update_error_password'] = 'Password has been failed to change. Please try again!';
$lang['confirm_error_password'] = 'New password and Confirm password values are not equal. Please try again!';
$lang['not_found_error_password'] = 'Current password error. Please enter your current password in Password field and try again!';

$lang['update_success_profile'] = 'User profile has been updated successfully!';
$lang['update_error_profile'] = 'User profile has been failed to update. Please try again!';

// user register
$lang['email_existed'] = 'This email has already been registered. Please try with different email.';
$lang['email_not_existed'] = 'This email is not existed in our system. Please try with different email.';
$lang['email_verified'] = 'YOUR ACCOUNT HAS BEEN SUCCESSFULLY ACTIVATED, PLEASE PLEASE PROCEED TO THE LOGIN SCREEN TO LOGIN NOW.';
$lang['email_not_verified'] = 'Email verification process has been failed. Please register again.';

// user login
$lang['login_failed'] = 'Login failed. Username and password combination is not valid.';
$lang['account_blocked'] = 'Your account is blocked.';
$lang['account_not_verified'] = 'Your account is not verified. please check your email for account activation.';
$lang['logout_success'] = 'You have successfully logged out of your account.';
$lang['reset_password'] = 'Reset password email has been successfully sent.';
$lang['invalid_email_code'] = 'Email verification process has been failed. Please try again.';
$lang['cart_login'] = 'You are successfully logged in.';

$lang['reset_password_text'] = 'RESET PASSWORD';
$lang['resend_btn'] = 'RESEND';


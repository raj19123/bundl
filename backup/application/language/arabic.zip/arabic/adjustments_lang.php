<?php 

$lang['update_success'] = 'Edited adjustment has been successfully updated.';
$lang['update_error'] = 'Edited adjustment has been failed to update.';

$lang['add_success'] = 'A new adjustment has been successfully added.';
$lang['add_error'] = 'A new adjustment has been failed to add.';

$lang['delete_success'] = 'Adjustment has been successfully deleted.';
$lang['delete_error'] = 'Adjustment has been failed to delete.';



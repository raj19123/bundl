<?php

$lang['update_success'] = 'Edited coupon has been successfully updated.';
$lang['update_error'] = 'Edited coupon has been failed to update.';

$lang['add_success'] = 'A new coupon has been successfully added.';
$lang['add_error'] = 'A new coupon has been failed to add.';

$lang['delete_success'] = 'coupon has been successfully deleted.';
$lang['delete_error'] = 'coupon has been failed to delete.';

$lang['contact_us'] = 'CONTACT US';
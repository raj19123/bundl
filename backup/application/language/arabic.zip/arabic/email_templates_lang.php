<?php


$lang['update_success'] = 'Edited email template has been successfully updated.';
$lang['update_error'] = 'Edited email template has been failed to update.';

$lang['add_success'] = 'A new email template has been successfully added.';
$lang['add_error'] = 'A new email template has been failed to add.';

$lang['delete_success'] = 'Email Template has been successfully deleted.';
$lang['delete_error'] = 'Email Template has been failed to delete.';

$lang['email_varification'] = 'VERIFICATION';
$lang['email_varification_description'] = 'You have been registered successfully.<br> A verification email has been sent to <?= isset($email) ? $email : ''; ?> . Please visit your registered email.';
